public class Module {
    public double moduleInput;
    public double moduleOutput;
    public int counter;
    public double mean;

   /* public Module(double input) {
        this.moduleInput = input;
        this.moduleOutput=0;
    }*/

    public Module(Object o) {

    }

    public Module() {
        this.counter = 0;

    }
}
