/*
 * $Id: stats.h,v 1.1 2011/10/03 00:17:22 sfeam Exp $
 */

/* GNUPLOT - stats.h */

#ifndef GNUPLOT_STAT_H
# define GNUPLOT_STAT_H

#include "syscfg.h"

void statsrequest __PROTO((void));

#endif /* GNUPLOT_STAT_H */
